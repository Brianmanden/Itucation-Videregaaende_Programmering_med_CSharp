﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 19 + 7;
            // cw
            // Console.WriteLine(19+7);

            // Variable
            // Named place in memory
            int x = 19;
            Console.WriteLine(x);

            string name = "Lasse 11111 ~~";
            Console.WriteLine(name);

            string y = "12";
            x = 14;
            Console.WriteLine(y+x);

            bool b = true;
            bool c = false;
            Console.WriteLine(12<3);
            
            // != - not same / ikke lig med
            // == - same / lig med
            Console.WriteLine(b != c);

            // variable names are case sensitive
            int a = 5;
            string A = "hello";
            Console.WriteLine(a+A);

            // allowed variable names
            int myVar = 3;
            int my_var = 5;
            int _my_var_ = 7;
            int MYVAR = 9;
            int _my_var_3298764 = 2;

            // variables name NOT allowed
            // int 5var = 5;
            // int my var = 7;

            // Korte men sigende navne
            // 'name' er bedre end 'n'
            // 'student_name' er bedre end 's_n'
            // 'name_length' er bedre end 'length_of_persons_name'

            // type conversion
            int i = 18;
            string nan = "26";

            string new_var = i.ToString();
            int blabla = int.Parse(nan);

            string navn = "Mark";
            int alder = 34;
            Console.WriteLine(navn + " er " + alder + " år gammel.");
            Console.WriteLine($"{navn} er {alder} år gammel.");

            Console.WriteLine("Her er et citat:\"Noget klogt\" ");

            string my_string = "mark bor i Mordor";
            Console.WriteLine(my_string[5]); // index starts at 0
            Console.WriteLine(my_string.ToLower());
            Console.WriteLine(my_string.ToUpper());

            Console.Write("Please enter your city name -> ");
            string place = Console.ReadLine();
            Console.WriteLine($"You have entered: {place}");
            Console.WriteLine(!place.StartsWith("m"));

            string new_place = " Aarhus ";
            Console.WriteLine(new_place.Trim());
            Console.WriteLine(new_place.TrimEnd());
            Console.WriteLine(new_place.TrimStart());

            double tal = 2.62;



            Console.ReadKey();

        }
    }
}
