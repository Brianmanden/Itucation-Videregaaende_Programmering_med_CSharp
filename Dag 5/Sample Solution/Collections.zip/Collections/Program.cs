﻿using System.Collections;

namespace Collections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Dictionary
            // key, value
            //Dictionary<string, string> dictCities = new Dictionary<string, string>();
            //dictCities.Add("blabla", "Aarhus");
            //dictCities.Add("blablabla", "Christiansfeld");
            //Console.WriteLine(dictCities["blabla"]);

            // FILO - First In Last Out
            //Stack s = new Stack();
            //s.Push(26);
            //s.Push("Kaffekop");
            //s.Push(55.42);
            ////s.Pop();
            //foreach (var item in s)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("-----------------------------");
            //// FIFO - First In First Out
            //Queue q = new Queue();
            //q.Enqueue(26);
            //q.Enqueue("Kaffekop");
            //q.Enqueue(55.42);
            ////q.Dequeue();
            //foreach (var item in q)
            //{
            //    Console.WriteLine(item);
            //}

            // ----------- type-bestemt ------------
            //Stack<int> tal = new Stack<int>();
            //tal.Push("hej");

            //Stack<object> objStack = new Stack<object>();
            //objStack.Push(1);
            //objStack.Push("En string");

            // Hash Set -------- Unique Values --------
            //HashSet<string> cities = new HashSet<string>();
            //HashSet<string> citiesList1 = new HashSet<string>() { "Valby", "Viby", "Rødby", "Tårnby" };
            //HashSet<string> citiesList2 = new HashSet<string>() { "Valby", "Viby", "Roskilde", "Odense" };
            //Console.WriteLine("----- List 1 -----");
            //Console.WriteLine(String.Join(", ", citiesList1));
            //Console.WriteLine("----- List 2 -----");
            //Console.WriteLine(String.Join(", ", citiesList2));
            //cities.UnionWith(citiesList1);
            //cities.UnionWith(citiesList2);
            //Console.WriteLine("---- All Cities ----");
            //Console.WriteLine(String.Join(", ", cities));
            //Console.WriteLine("----- Common in List 1 & 2 -----");
            //citiesList1.IntersectWith(citiesList2);
            //citiesList1.Add("Valby");
            //Console.WriteLine(String.Join(", ", citiesList1));

            MyLinkedList lst = new MyLinkedList();
            lst.Add("AAAAAAAAA");
            lst.Add("BBBBBBBBB");
            lst.Add("CCCCCCCCC");
            lst.Add(2, "DDDDDDDDD");
            //lst.Add(-1, "blabla");
            lst.Print();
            Console.WriteLine("----- AFTER REMOVE -----");
            lst.RemoveAt(2);
            lst.Print();

        }
    }
}